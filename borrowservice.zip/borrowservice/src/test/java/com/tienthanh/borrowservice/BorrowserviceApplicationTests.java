package com.tienthanh.borrowservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BorrowserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
